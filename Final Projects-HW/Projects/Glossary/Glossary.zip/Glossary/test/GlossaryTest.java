import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;

/**
 * *
 *
 * @author David Park
 *
 */
public class GlossaryTest {
    private static final String INPUT_FILE = "terms.txt";
    private static final String OUTPUT_FOLDER = "data";

    @Before
    public void setUp() {
        File outputFolder = new File(OUTPUT_FOLDER);
        if (!outputFolder.exists()) {
            outputFolder.mkdir();
        }
    }

    @Test
    public void testGenerateHTMLPages() {
        Glossary.generateHTMLPages(INPUT_FILE, OUTPUT_FOLDER);

        File indexFile = new File(OUTPUT_FOLDER + "/index.html");
        assertTrue(indexFile.exists());

        File termPage1 = new File(OUTPUT_FOLDER + "/term1.html");
        assertTrue(termPage1.exists());
    }

    @Test
    public void testReadTerms() {
        SimpleReader inFile = new SimpleReader1L(INPUT_FILE);
        Map<String, String> dictionary = new Map1L<>();

        Glossary.readTerms(inFile, dictionary);

        assertEquals("Definition of Term 1", dictionary.value("Term 1"));
    }

    @Test
    public void testSortTerms() {
        Map<String, String> dictionary = new Map1L<>();
        dictionary.add("Term 2", "Definition of Term 2");
        dictionary.add("Term 1", "Definition of Term 1");

        Queue<String> sortedTerms = Glossary.sortTerms(dictionary);

        assertEquals("Term 1", sortedTerms.dequeue());
        assertEquals("Term 2", sortedTerms.dequeue());
    }

    @Test
    public void testWriteIndexHtml() {
        Queue<String> terms = new Queue1L<>();
        terms.enqueue("Term 1");
        terms.enqueue("Term 2");

        Glossary.writeIndexHtml(terms, OUTPUT_FOLDER);

        String expectedIndexContent = "<html><head><title>Glossary Index</title></head><body>\n"
                + "<h1>Glossary Index</h1><ul>\n"
                + "<li><a href=\"Term 1.html\">Term 1</a></li>\n"
                + "<li><a href=\"Term 2.html\">Term 2</a></li>\n"
                + "</ul></body></html>\n";
        assertEquals(expectedIndexContent,
                this.fileContentsAsString(OUTPUT_FOLDER + "/index.html"));
    }

    @Test
    public void testWriteTermPages() {
        Map<String, String> dictionary = new Map1L<>();
        dictionary.add("Term 1", "Definition of Term 1");
        dictionary.add("Term 2", "Definition of Term 2");

        Glossary.writeTermPages(dictionary, OUTPUT_FOLDER);

        String expectedTermPage1Content = "<html><head><title>Term 1</title></head><body>\n"
                + "<h1 style='color:red; font-weight:bold; font-style:italic;'>Term 1</h1>\n"
                + "<p>Definition of Term 1</p>\n"
                + "<p>Return to <a href=\"index.html\">Index</a>.</p>\n"
                + "</body></html>\n";
        assertEquals(expectedTermPage1Content,
                this.fileContentsAsString(OUTPUT_FOLDER + "/Term 1.html"));
    }

    @Test
    public void testFormatDefinition() {
        Map<String, String> dictionary = new Map1L<>();
        dictionary.add("Term 1", "Definition of Term 1");
        dictionary.add("Term 2", "Definition of Term 2");

        String definition = "This is a definition that contains Term 1 and Term 2.";
        String formattedDefinition = Glossary.formatDefinition(definition,
                dictionary);

        String expectedFormattedDefinition = "This is a definition that contains <a href=\"Term 1.html\">Term 1</a> and <a href=\"Term 2.html\">Term 2</a>.";
        assertEquals(expectedFormattedDefinition, formattedDefinition);
    }

    private String fileContentsAsString(String filename) {
        SimpleReader reader = new SimpleReader1L(filename);
        StringBuilder contents = new StringBuilder();

        while (!reader.atEOS()) {
            contents.append(reader.nextLine()).append("\n");
        }
        reader.close();
        return contents.toString();
    }
}