import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 *
 * This program processes a glossary text file to generate an HTML glossary. It
 * reads a list of terms and their definitions, sorts them, and creates an HTML
 * index along with individual pages for each term.
 *
 * @author David Park
 *
 */
public final class Glossary {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Glossary() {
    }

    /**
     * Processes the input file and writes sorted glossary terms and their
     * definitions to HTML files.
     *
     * @param inputFilePath
     *            the path to the glossary input file
     * @param outputFolderPath
     *            the directory path where HTML files will be saved
     */
    public static void generateHTMLPages(String inputFilePath,
            String outputFolderPath) {
        SimpleReader inFile = new SimpleReader1L(inputFilePath);
        Map<String, String> dictionary = new Map1L<>();
        readTerms(inFile, dictionary);
        inFile.close();

        Queue<String> sortedTerms = sortTerms(dictionary);
        writeIndexHtml(sortedTerms, outputFolderPath);
        writeTermPages(dictionary, outputFolderPath);
    }

    /**
     * Reads terms and their definitions from a file and stores them in a map.
     *
     * @param inFile
     *            the SimpleReader to read from the input file
     * @param dictionary
     *            the map to store terms and definitions
     */
    public static void readTerms(SimpleReader inFile,
            Map<String, String> dictionary) {
        boolean hasActiveKey = false;
        String key = "";
        StringBuilder value = new StringBuilder();
        // Continue reading lines until the end of the file is reached
        while (!inFile.atEOS()) {
            String line = inFile.nextLine();
            // If the line is empty (a blank line)
            if (line.trim().isEmpty()) {
                // If there is an active key, add the key-value pair to the dictionary
                if (hasActiveKey) {
                    dictionary.add(key, value.toString().trim());
                    hasActiveKey = false;
                    value = new StringBuilder();
                }
            } else if (line.indexOf(' ') == -1) {
                // if key is found but the previous key is still active
                if (hasActiveKey) {
                    dictionary.add(key, value.toString().trim());
                    value = new StringBuilder();
                }
                key = line.trim();
                hasActiveKey = true;
            } else {
                value.append(line).append(" ");
            }
        }
        // If active key, add the last key-value pair
        if (hasActiveKey) {
            dictionary.add(key, value.toString().trim());
        }
    }

    /**
     * Sorts the terms in alphabetical order using a sequence.
     *
     * @param dictionary
     *            the map containing terms and their definitions
     * @return a queue containing the sorted terms
     */
    public static Queue<String> sortTerms(Map<String, String> dictionary) {
        Sequence<String> terms = new Sequence1L<>();
        for (Map.Pair<String, String> term : dictionary) {
            int position = 0;
            // Find the correct position to insert in sorted order
            while (position < terms.length()
                    && terms.entry(position).compareTo(term.key()) < 0) {
                position++;
            }
            terms.add(position, term.key()); // Insert the term at the found position
        }

        // Now transfer the sorted terms from the Sequence to the Queue
        Queue<String> sortedTerms = new Queue1L<>();
        while (terms.length() > 0) {
            sortedTerms.enqueue(terms.remove(0));
            // Remove from the sequence and enqueue to the queue
        }

        return sortedTerms; // Return the queue with sorted terms
    }

    /**
     * Writes the index HTML file containing links to each term's page.
     *
     * @param terms
     *            the queue of sorted terms
     * @param outputFolderPath
     *            the path where the index.html file will be written
     */
    public static void writeIndexHtml(Queue<String> terms,
            String outputFolderPath) {
        // Create a new SimpleWriter to write the index.html file
        SimpleWriter indexFile = new SimpleWriter1L(
                outputFolderPath + "/index.html");
        // Write the opening HTML tags and the head section
        indexFile.println(
                "<html><head><title>Glossary Index</title></head><body>");
        // Write the main heading for the index page
        indexFile.println("<h1>Glossary Index</h1><ul>");
        // Iterate over each term in the queue
        for (String term : terms) {
            indexFile.println(
                    "<li><a href=\"" + term + ".html\">" + term + "</a></li>");
        }
        // Write the closing HTML tags
        indexFile.println("</ul></body></html>");
        indexFile.close();
    }

    /**
     * Writes HTML pages for each term with their definitions formatted.
     *
     * @param dictionary
     *            the map containing terms and their definitions
     * @param outputFolderPath
     *            the path where term HTML files will be written
     */
    public static void writeTermPages(Map<String, String> dictionary,
            String outputFolderPath) {
        // Iterate over each entry in the dictionary
        for (Map.Pair<String, String> entry : dictionary) {
            // Create a new SimpleWriter to write the HTML file for the current term
            SimpleWriter termFile = new SimpleWriter1L(
                    outputFolderPath + "/" + entry.key() + ".html");
            // Write the opening HTML tags and the head section
            termFile.println("<html><head><title>" + entry.key()
                    + "</title></head><body>");
            // Write the term as a styled heading
            termFile.println(
                    "<h1 style='color:red; font-weight:bold; font-style:italic;'>"
                            + entry.key() + "</h1>");
            // Write the formatted definition of the term
            termFile.println("<p>" + formatDefinition(entry.value(), dictionary)
                    + "</p>");
            // Write a link to return to the index page
            termFile.println(
                    "<p>Return to <a href=\"index.html\">Index</a>.</p>");
            // Write the closing HTML tags
            termFile.println("</body></html>");
            termFile.close();
        }
    }

    /**
     * Formats the definition of a term by embedding hyperlinks to referenced
     * terms within the glossary. This ensures that each term within the
     * definition that matches a term in the glossary is clickable and links to
     * the respective term page.
     *
     * @param definition
     *            the definition to format
     * @param dictionary
     *            the map containing all terms and their definitions for lookup
     * @return the formatted definition with HTML hyperlinks embedded
     */
    public static String formatDefinition(String definition,
            Map<String, String> dictionary) {
        Set<String> terms = new Set1L<>();
        // Iterate over each entry in the dictionary and add the terms to the set
        for (Map.Pair<String, String> entry : dictionary) {
            terms.add(entry.key()); // Collect all terms for quick lookup
        }

        // Split definition into words considering punctuation and spaces
        String[] words = definition.split("\\s+");

        StringBuilder formatted = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String fragment = words[i];
            String cleanedFragment = fragment.replaceAll("[^a-zA-Z]", "");
            // Clean word of punctuation

            if (terms.contains(cleanedFragment)) {
                // Replace the term with a hyperlink only if it's a standalone term
                formatted.append(fragment.replace(cleanedFragment,
                        "<a href=\"" + cleanedFragment + ".html\">"
                                + cleanedFragment + "</a>"));
            } else {
                formatted.append(fragment);
            }
            // Append a space after each word
            formatted.append(' ');
        }
        // Return the formatted definition string after trim
        return formatted.toString().trim();
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        // call the path to glossary input file
        out.print("Enter the path to the glossary input file: ");
        String inputFilePath = in.nextLine();
        // get output folder you are going to output to.
        out.print("Enter the path to the output folder: ");
        String outputFolderPath = in.nextLine();

        // run generateHTML
        generateHTMLPages(inputFilePath, outputFolderPath);

        in.close();
        out.close();
    }
}
