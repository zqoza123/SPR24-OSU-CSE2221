import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class StringReassemblyTest {

    @Test
    public void testOverlap_stream() {
        String str1 = "broadcast";
        String str2 = "casting";
        int overlap = StringReassembly.overlap(str1, str2);
        assertEquals(4, overlap);
    }

    @Test
    public void testOverlap_prefixsuffix() {
        String str1 = "prefixsuffix";
        String str2 = "ixsuffixplus";
        int overlap = StringReassembly.overlap(str1, str2);
        assertEquals(8, overlap);
    }

    @Test
    public void testOverlap_nointersect() {
        String str1 = "nointersect";
        String str2 = "completely";
        int overlap = StringReassembly.overlap(str1, str2);
        assertEquals(0, overlap);
    }

    @Test
    public void testCombination_stream() {
        String str1 = "stre";
        String str2 = "ream";
        int overlap = 2;
        String combine = StringReassembly.combination(str1, str2, overlap);
        assertEquals("stream", combine);
    }

    @Test
    public void testCombination_prefixsuffix() {
        String str1 = "overlap";
        String str2 = "lapping";
        int overlap = 3;
        String combine = StringReassembly.combination(str1, str2, overlap);
        assertEquals("overlapping", combine);
    }

    @Test
    public void testAddToSetAvoidingSubstrings_1() {
        Set<String> test = new Set1L<>();
        test.add("abc");
        test.add("def");
        test.add("jkl");
        String str = "jklmn";
        Set<String> expected = new Set1L<>();
        expected.add("abc");
        expected.add("def");
        expected.add("jklmn");
        StringReassembly.addToSetAvoidingSubstrings(test, str);
        assertEquals(expected, test);
    }

    @Test
    public void testAddToSetAvoidingSubstrings_2() {
        Set<String> test = new Set1L<>();
        test.add("123");
        test.add("456");
        String str = "456789";
        Set<String> expected = new Set1L<>();
        expected.add("123");
        expected.add("456789");
        StringReassembly.addToSetAvoidingSubstrings(test, str);
        assertEquals(expected, test);
    }

    @Test
    public void testAssemble_1() {
        Set<String> test = new Set1L<>();
        test.add("part1 ");
        test.add("1 part2");
        test.add("part2 part3");
        Set<String> expected = new Set1L<>();
        expected.add("part1 part2 part3");
        StringReassembly.assemble(test);
        assertEquals(expected, test);
    }

    @Test
    public void testAssemble_2() {
        Set<String> test = new Set1L<>();
        test.add("123");
        test.add("234");
        test.add("345");
        test.add("456");
        Set<String> expected = new Set1L<>();
        expected.add("123456");
        StringReassembly.assemble(test);
        assertEquals(expected, test);
    }

    @Test
    public void testPrintWithLineSeparators_1() {
        SimpleWriter out = new SimpleWriter1L("test.txt");
        SimpleReader in = new SimpleReader1L("test.txt");
        String text = "ABC~DEF~GHI";
        String expected = "ABC\nDEF\nGHI";
        StringReassembly.printWithLineSeparators(text, out);
        String test1 = in.nextLine();
        String test2 = in.nextLine();
        String test3 = in.nextLine();
        in.close();
        out.close();
        assertEquals(expected, test1 + "\n" + test2 + "\n" + test3);
    }

    @Test
    public void testPrintWithLineSeparators_2() {
        SimpleWriter out = new SimpleWriter1L("test.txt");
        SimpleReader in = new SimpleReader1L("test.txt");
        String text = "123~456~789";
        String expected = "123\n456\n789";
        StringReassembly.printWithLineSeparators(text, out);
        String test1 = in.nextLine();
        String test2 = in.nextLine();
        String test3 = in.nextLine();
        in.close();
        out.close();
        assertEquals(expected, test1 + "\n" + test2 + "\n" + test3);
    }

    @Test
    public void testLinesFromInput_1() {
        SimpleReader in = new SimpleReader1L("xd.txt");
        Set<String> test = new Set1L<>();
        Set<String> expected = new Set1L<>();
        expected.add("Bucks -- Beat");
        expected.add("Go Bucks");
        expected.add("o Bucks -- B");
        expected.add("Beat Mich");
        expected.add("Michigan~");
        test = StringReassembly.linesFromInput(in);
        assertEquals(test, expected);
    }
}
