import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author David Park
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model,
            NNCalcView view) {

        NaturalNumber in = model.top();
        NaturalNumber out = model.bottom();

        // Update the top and bottom display to show top n bottom number

        view.updateTopDisplay(in);
        view.updateBottomDisplay(out);
        // Enable the subtract button if >= top number
        view.updateSubtractAllowed(out.compareTo(in) <= 0);
        // Enable the divide button if the bottom number is not zero
        view.updateDivideAllowed(!out.isZero());
        // Enable the root button if the bottom number is 2-limit
        view.updateRootAllowed(
                out.compareTo(TWO) >= 0 && out.compareTo(INT_LIMIT) <= 0);
        view.updatePowerAllowed(out.compareTo(INT_LIMIT) <= 0);
    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {
        this.model = model;
        this.view = view;
        updateViewToMatchModel(model, view);
    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {
        NaturalNumber in = this.model.top();
        NaturalNumber out = this.model.bottom();

        //Processes an "Enter" event which copies the bottom number to the top.

        in.copyFrom(out);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddEvent() {
        NaturalNumber in = this.model.top();
        NaturalNumber out = this.model.bottom();

        // Processes an "Add" event where the top number is added to the
        // bottom number, and the top is then cleared.

        out.add(in);
        in.clear();

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSubtractEvent() {
        NaturalNumber in = this.model.top();
        NaturalNumber out = this.model.bottom();

        // Processes a "Subtract" event where the top number is subtracted
        // from the bottom number, then the result is transferred to the bottom.

        in.subtract(out);
        out.transferFrom(in);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processMultiplyEvent() {
        NaturalNumber in = this.model.top();
        NaturalNumber out = this.model.bottom();

        // Processes a "Multiply" event where the top number is multiplied
        // with the bottom number, and the top is then cleared.

        out.multiply(in);
        in.clear();

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processDivideEvent() {
        NaturalNumber in = this.model.top();
        NaturalNumber out = this.model.bottom();
        NaturalNumber remainder = in.newInstance();
        // Processes a "Divide" event, dividing the top number by the bottom,
        // storing the quotient in bottom, and remainder in top.
        remainder = in.divide(out);
        out.transferFrom(in);
        in.transferFrom(remainder);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processPowerEvent() {
        NaturalNumber in = this.model.top();
        NaturalNumber out = this.model.bottom();
        int ex = out.toInt();

        //Processes a "Power" event where the bottom number is treated as the
        // exponent to raise the top number.

        in.power(ex);
        out.transferFrom(in);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processRootEvent() {
        NaturalNumber in = this.model.top();
        NaturalNumber out = this.model.bottom();

        //Processes a "Root" event where the bottom number is treated as
        // the 'n' in an nth-root operation on the top number.

        int rootNum = out.toInt();
        in.root(rootNum);
        out.transferFrom(in);

        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processAddNewDigitEvent(int digit) {
        //Processes an event to add a new digit to the bottom number by
        // multiplying the bottom number by 10 and adding the digit.
        NaturalNumber out = this.model.bottom();
        out.multiplyBy10(digit);
        updateViewToMatchModel(this.model, this.view);
    }

}
